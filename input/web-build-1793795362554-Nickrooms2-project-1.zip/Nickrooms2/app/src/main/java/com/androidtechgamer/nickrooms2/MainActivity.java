package com.androidtechgamer.nickrooms2;

import android.app.Activity;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        ImageView background = new ImageView(this);
        background.setImageResource(R.drawable.nickrooms_background);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(background, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText("NICKROOMS 2");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setShadowLayer(8f, 2f, 2f, Color.BLACK);
        FrameLayout.LayoutParams titleParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        titleParams.bottomMargin = 36;
        root.addView(title, titleParams);
        setContentView(root);

        setWallpaperFromImage();
        playAudioOnly();
    }

    private void setWallpaperFromImage() {
        WallpaperManager manager = WallpaperManager.getInstance(this);
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nickrooms_background);
        if (bitmap == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM);
            } else {
                manager.setBitmap(bitmap);
            }
            Toast.makeText(this, "Nickrooms wallpaper applied", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Android couldn't apply the wallpaper", Toast.LENGTH_LONG).show();
        } finally {
            bitmap.recycle();
        }
    }

    private void playAudioOnly() {
        releasePlayer();
        player = MediaPlayer.create(this, R.raw.video1);
        if (player != null) {
            player.setOnCompletionListener(mp -> releasePlayer());
            player.start();
        }
        // No video surface is created: only the MP4's audio track is played.
    }

    private void releasePlayer() {
        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }
}
