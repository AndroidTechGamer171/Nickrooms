NICKROOMS 2 - Android project

Features:
- Uses the supplied first image as the launcher icon and in-app background.
- Attempts to set that same image as the device's SYSTEM wallpaper on app launch.
- Plays only the audio track from the supplied Video 1 MP4. No video is displayed.
- No network access, no data collection, and no device reboot behavior.

Package: com.androidtechgamer.nickrooms2
Minimum Android: 6.0 (API 23)
Compile/Target SDK: 35
Java: 17

Build with Android Gradle Plugin 8.6.1 and Gradle 8.7+ using JDK 17.
