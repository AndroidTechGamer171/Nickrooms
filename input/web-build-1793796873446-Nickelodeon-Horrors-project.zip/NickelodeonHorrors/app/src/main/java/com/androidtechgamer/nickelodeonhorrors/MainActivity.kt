package com.androidtechgamer.nickelodeonhorrors

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("horrors_settings", MODE_PRIVATE) }
    private var showLockerOnReturn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyWallpaper()
        startAudio()
        buildScreen()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 9)
        }
    }

    private fun applyWallpaper() {
        try {
            val bitmap = BitmapFactory.decodeResource(resources, R.drawable.nickelodeon_horrors)
            WallpaperManager.getInstance(this).setBitmap(bitmap)
            bitmap.recycle()
        } catch (_: Exception) {
            Toast.makeText(this, "Wallpaper could not be changed. You can set it manually.", Toast.LENGTH_LONG).show()
        }
    }

    private fun startAudio() {
        val intent = Intent(this, AudioLoopService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
    }

    private fun buildScreen() {
        val root = FrameLayout(this)
        val background = ImageView(this).apply {
            setImageResource(R.drawable.nickelodeon_horrors)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Nickelodeon Horrors background"
        }
        root.addView(background, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this).apply { setBackgroundColor(0x55000000) }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val title = TextView(this).apply {
            text = "NICKELODEON HORRORS"
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
            setShadowLayer(8f, 2f, 2f, Color.BLACK)
        }
        root.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        setContentView(root)
    }

    override fun onPause() {
        super.onPause()
        showLockerOnReturn = true
    }

    override fun onResume() {
        super.onResume()
        if (showLockerOnReturn && !prefs.getBoolean("liked", false)) {
            showLockerOnReturn = false
            showFeedbackLocker()
        }
    }

    private fun showFeedbackLocker() {
        if (isFinishing || prefs.getBoolean("liked", false)) return
        val dialog = AlertDialog.Builder(this)
            .setTitle("🔒 NICKELodeon HORRORS")
            .setMessage("DID YOU LIKE NICKELODEON HORRORS?")
            .setCancelable(false)
            .setPositiveButton("YES", null)
            .setNegativeButton("NO", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
                setTextColor(Color.RED)
                setOnClickListener {
                    // NO deliberately keeps the locker open.
                    Toast.makeText(this@MainActivity, "The locker stays until you choose YES!", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
                setTextColor(Color.rgb(0, 130, 0))
                setOnClickListener {
                    prefs.edit().putBoolean("liked", true).apply()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }
}
