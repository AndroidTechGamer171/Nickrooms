# Nickelodeon Horrors

Android Studio / AndroidForge-compatible Gradle project.

## Features
- Uses the supplied red Nickelodeon Horrors artwork as launcher icon and in-app background.
- Attempts to set the same artwork as the device wallpaper at launch (Android wallpaper permission required).
- Extracts and loops the audio track from the supplied Video 1; the video picture is never displayed.
- Uses a foreground media-playback service so audio can continue while the app is backgrounded. Android shows a persistent playback notification. The service stops when the app task is removed.
- On returning to the app after leaving it, shows a non-cancelable feedback locker. YES dismisses it permanently; NO leaves the choice pending for the next return.

## Build
Push the project contents to a GitHub repository, then run **Build Nickelodeon Horrors APK** under Actions. Download the `Nickelodeon-Horrors-debug-apk` artifact.

Android 13+ may ask for notification permission. If denied, Android may hide the playback notification; the app still requests foreground playback. Device battery settings can affect background playback.
