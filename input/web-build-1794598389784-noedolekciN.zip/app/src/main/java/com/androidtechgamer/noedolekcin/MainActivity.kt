
package com.androidtechgamer.noedolekcin

import android.app.Activity
import android.app.WallpaperManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.widget.*
import android.net.Uri

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var coins = 0
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        setContentView(root)

        setFirstWallpaper()

        handler.postDelayed({
            setSecondWallpaper()
            playIntro()
        }, 5000)
    }

    private fun setFirstWallpaper() {
        try {
            val bitmap = BitmapFactory.decodeResource(
                resources, R.drawable.wallpaper_first
            )
            WallpaperManager.getInstance(this).setBitmap(bitmap)
            bitmap.recycle()
        } catch (e: Exception) {
            Toast.makeText(this, "Wallpaper 1 failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSecondWallpaper() {
        try {
            val original = BitmapFactory.decodeResource(
                resources, R.drawable.wallpaper_second
            )

            val bitmap = original.copy(Bitmap.Config.ARGB_8888, true)
            original.recycle()

            val canvas = Canvas(bitmap)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = bitmap.width * 0.045f
                textAlign = Paint.Align.CENTER
                setShadowLayer(6f, 2f, 2f, Color.BLACK)
            }

            canvas.drawText(
                "There Much Better",
                bitmap.width / 2f,
                bitmap.height - 60f,
                paint
            )

            WallpaperManager.getInstance(this).setBitmap(bitmap)
            bitmap.recycle()

        } catch (e: Exception) {
            Toast.makeText(this, "Wallpaper 2 failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playIntro() {
        root.removeAllViews()

        val video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.app_icon)
        logo.setPadding(8, 8, 8, 8)

        val logoParams = FrameLayout.LayoutParams(
            80, 80, Gravity.TOP or Gravity.END
        )
        root.addView(logo, logoParams)

        logo.setOnClickListener {
            openClickerGame()
        }

        video.setVideoURI(
            Uri.parse("android.resource://$packageName/${R.raw.intro_video}")
        )

        video.setOnPreparedListener {
            video.start()
        }
    }

    private fun openClickerGame() {
        root.removeAllViews()

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.gravity = Gravity.CENTER
        layout.setBackgroundColor(Color.BLACK)

        val title = TextView(this)
        title.text = "NICKELODEON CLICKER"
        title.textSize = 28f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER

        val score = TextView(this)
        score.text = "Coins: $coins"
        score.textSize = 24f
        score.setTextColor(Color.YELLOW)

        val clickButton = Button(this)
        clickButton.text = "CLICK FOR COINS!"

        clickButton.setOnClickListener {
            coins++
            score.text = "Coins: $coins"
        }

        layout.addView(title)
        layout.addView(score)
        layout.addView(clickButton)

        root.addView(layout)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
