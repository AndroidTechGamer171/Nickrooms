noedolekciN

App name: noedolekciN

Package name: com.androidtechgamer.noedolekcin

Platform: Android

Target SDK: 35

Minimum SDK: 23

Startup sequence

1. Set wallpaper Image 2.
2. Wait 5 seconds.
3. Set wallpaper Image 3.
4. Display the text: There Much Better.
5. Play Video 1.

Hidden feature

Tap the Nickelodeon logo to open the hidden Nickelodeon clicker game.

Project status

Android app source project — not yet compiled.