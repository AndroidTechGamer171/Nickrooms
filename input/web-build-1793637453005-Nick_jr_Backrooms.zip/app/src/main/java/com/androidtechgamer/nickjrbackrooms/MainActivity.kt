package com.androidtechgamer.nickjrbackrooms

import android.app.Activity
import android.app.WallpaperManager
import android.os.Bundle
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.media.MediaPlayer
import android.graphics.BitmapFactory

class MainActivity : Activity() {

    private var gameOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            val bitmap = BitmapFactory.decodeResource(
                resources,
                R.drawable.nickjr_backrooms
            )
            WallpaperManager.getInstance(this).setBitmap(bitmap)
            bitmap.recycle()
        } catch (_: Exception) {}

        showHome()
    }

    private fun showHome() {
        gameOpen = false

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(18, 18, 24))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.nickjr_backrooms)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setOnClickListener { showGame() }
        }

        root.addView(
            logo,
            LinearLayout.LayoutParams(-1, 150)
        )

        val title = TextView(this).apply {
            text = "NICK JR BACKROOMS"
            textSize = 22f
            setTextColor(Color.YELLOW)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }

        root.addView(title)

        val videoTitle = TextView(this).apply {
            text = "VIDEO 1"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        root.addView(videoTitle)

        val video = VideoView(this)

        root.addView(
            video,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        setContentView(root)

        val uri = android.net.Uri.parse(
            "android.resource://$packageName/${R.raw.video1}"
        )

        video.setVideoURI(uri)

        video.setOnPreparedListener { player ->
            player.isLooping = true
            video.start()
        }
    }

    private fun showGame() {
        gameOpen = true

        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.rgb(28, 34, 42))

        frame.addView(
            MiniFlapGame(),
            FrameLayout.LayoutParams(-1, -1)
        )

        val back = TextView(this).apply {
            text = "← BACK TO VIDEO"
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(18, 18, 18, 18)
            setOnClickListener { showHome() }
        }

        frame.addView(
            back,
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START)
        )

        setContentView(frame)
    }

    override fun onBackPressed() {
        if (gameOpen) {
            showHome()
        } else {
            super.onBackPressed()
        }
    }

    inner class MiniFlapGame : View(this@MainActivity) {

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        private var birdY = 0f
        private var velocity = 0f
        private var started = false
        private var score = 0
        private var pipeX = 900f
        private var gapY = 500f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)

            val w = width.toFloat()
            val h = height.toFloat()

            canvas.drawColor(Color.rgb(190, 220, 150))

            paint.color = Color.rgb(238, 220, 120)
            canvas.drawRect(0f, h * .82f, w, h, paint)

            if (!started) birdY = h * .45f

            paint.color = Color.rgb(255, 145, 30)
            canvas.drawCircle(w * .28f, birdY, 22f, paint)

            paint.color = Color.rgb(55, 145, 65)

            canvas.drawRect(
                pipeX, 0f, pipeX + 65f, gapY - 95f, paint
            )

            canvas.drawRect(
                pipeX, gapY + 95f, pipeX + 65f, h * .82f, paint
            )

            paint.color = Color.BLACK
            paint.textSize = 38f
            canvas.drawText("SCORE: $score", w - 230f, 60f, paint)

            paint.textSize = 24f
            canvas.drawText(
                if (started) "TAP TO FLAP" else "TAP TO START",
                25f, h * .18f, paint
            )

            if (started) {
                velocity += 0.65f
                birdY += velocity
                pipeX -= 5f

                if (pipeX < -70f) {
                    pipeX = w + 80f
                    gapY = h * .35f +
                        Math.random().toFloat() * h * .25f
                    score++
                }

                val hitPipe =
                    w * .28f + 22f > pipeX &&
                    w * .28f - 22f < pipeX + 65f &&
                    (birdY < gapY - 95f ||
                     birdY > gapY + 95f)

                if (birdY > h * .82f || birdY < 0f || hitPipe) {
                    started = false
                    score = 0
                    pipeX = w + 80f
                }

                postInvalidateDelayed(16)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN) {
                started = true
                velocity = -10f
                invalidate()
                return true
            }

            return true
        }
    }
}