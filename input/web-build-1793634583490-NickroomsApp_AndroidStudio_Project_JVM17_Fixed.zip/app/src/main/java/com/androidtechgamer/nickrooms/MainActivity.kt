package com.androidtechgamer.nickrooms

import android.app.Activity
import android.app.WallpaperManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val manager = WallpaperManager.getInstance(this)
            assets.open("nickrooms_wallpaper.jpg").use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream)
                manager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                bitmap.recycle()
            }
            Toast.makeText(this, "NICKROOMS: Wallpaper applied!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't apply wallpaper on this device.", Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
