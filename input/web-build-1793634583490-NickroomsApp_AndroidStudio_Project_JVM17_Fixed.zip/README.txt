NICKROOMS APP — Android Studio source project

Uses your first uploaded image as its launcher icon.
When opened, it immediately applies your second uploaded image as the HOME SCREEN wallpaper.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android tablet.

This is a source project, not a precompiled APK. The app changes the home-screen
wallpaper only. Your launcher may crop the image to fit its home-screen layout.
