# Old MSM Revival — Build 0.2

An original fan-made Android prototype inspired by the general classic monster-island music-game genre. It is NOT the official My Singing Monsters game, does not restore the 2018 app/server, and does not contain its proprietary monsters, artwork, music, text, or account data.

## Implemented prototype systems
- Four selectable island themes: Plant, Cold, Air, Water
- A 120-entry original procedural monster catalogue
- Four rarity tiers: Common, Rare, Epic, Legendary
- Prototype breeding timer and sequential discovery
- Coin collection
- Vegetable farm with grow/harvest timer
- Feeding consumes food and increases monster level
- Castle with bed capacity upgrades
- Simple original generated-tone island sequence
- Local save using SharedPreferences

## Known prototype limitations
- This is a systems prototype, not a finished commercial-quality game.
- The 120 catalogue entries are procedural placeholder creatures, not the official 2018 MSM roster.
- Breeding is a simplified timer and unlocks the next catalogue entry; it does not yet calculate species-specific combinations.
- Island art, decorations, monsters, UI and sounds are original placeholders.
- No online features, cloud sync, ads, purchases, or server.
- More detailed art, sound composition, balancing, animations, tutorial, and device testing remain.

## Build
Open the folder in Android Studio, sync Gradle, then Build > Build APK(s).
- applicationId: com.androidtechgamer.oldmsmrevival
- compileSdk: 35
- targetSdk: 35
- minSdk: 23
- version: 0.2.0

AndroidForge compatibility depends on its supported import format. This ZIP is a standard Android Studio Gradle project; it is not an APK.
