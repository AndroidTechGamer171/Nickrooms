package com.androidtechgamer.oldmsmrevival;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Path;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.view.MotionEvent;
import android.view.View;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

public class GameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;
    private final String[] tabs = {"ISLAND","BREED","FARM","CASTLE","MONSTERS"};
    private final String[] islands = {"PLANT","COLD","AIR","WATER"};
    private final String[] syllA = {"Moss","Bloop","Peb","Zing","Wub","Fuzz","Glim","Bram","Tink","Murk","Puff","Snor"};
    private final String[] syllB = {"bit","adoo","blit","zo","wump","gle","bop","nook","let","muff"};
    private final int[] rarityColors = {0xFF70B86B,0xFF64B9D0,0xFFB17AD6,0xFFFFC44D};
    private int page = 0, island = 0, unlocked = 3, pageMonsters = 0;
    private int coins = 500, food = 0, castleLevel = 1, selectedMonster = 0;
    private int monsterLevel[] = new int[120];
    private long breedFinish = 0, cropFinish = 0;
    private boolean eggReady = false, cropReady = false;
    private String status = "WELCOME TO YOUR ISLAND!";
    private float sx = 1, sy = 1;
    private ToneGenerator tone;
    private long lastTap = 0;

    public GameView(Context c) {
        super(c);
        prefs = c.getSharedPreferences("old_msm_save", Context.MODE_PRIVATE);
        tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 65);
        load();
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private String monsterName(int id) {
        return syllA[id % syllA.length] + syllB[(id * 7 + id / 3) % syllB.length];
    }
    private String rarity(int id) {
        if (id < 50) return "COMMON";
        if (id < 80) return "RARE";
        if (id < 105) return "EPIC";
        return "LEGENDARY";
    }
    private int rarityColor(int id) {
        if (id < 50) return rarityColors[0];
        if (id < 80) return rarityColors[1];
        if (id < 105) return rarityColors[2];
        return rarityColors[3];
    }
    private void fill(Canvas c, int color) { p.setColor(color); p.setStyle(Paint.Style.FILL); }
    private void label(Canvas c, String s, float x, float y, float size, int color) {
        p.setColor(color); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true); c.drawText(s,x,y,p); p.setFakeBoldText(false);
    }
    private void button(Canvas c, float l,float t,float r,float b,String s,int color) {
        fill(c,color); c.drawRoundRect(new RectF(l,t,r,b),13,13,p);
        label(c,s,(l+r)/2,(t+b)/2+6,15,0xFFFFFFFF);
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        sx=getWidth()/900f; sy=getHeight()/500f;
        canvas.save(); canvas.scale(sx,sy);
        fill(canvas,0xFF75C9E8); canvas.drawRect(0,0,900,500,p);
        fill(canvas,0xFFFFE7A0); canvas.drawCircle(805,65,34,p);
        fill(canvas,0xFFFFFFFF);
        canvas.drawOval(new RectF(80,65,205,105),p); canvas.drawOval(new RectF(135,45,250,110),p);
        fill(canvas,0xFF1B5547); canvas.drawRect(0,0,900,104,p);
        label(canvas,"OLD MSM REVIVAL",450,39,27,0xFFFFD66B);
        label(canvas,"FAN-MADE  •  BUILD 0.2  •  COINS: "+coins+"  •  FOOD: "+food,450,72,14,0xFFFFFFFF);
        for(int i=0;i<tabs.length;i++) {
            float l=12+i*176;
            button(canvas,l,112,l+164,151,tabs[i],page==i?0xFF174F43:0xFF537F71);
        }
        if(page==0) drawIsland(canvas);
        if(page==1) drawBreed(canvas);
        if(page==2) drawFarm(canvas);
        if(page==3) drawCastle(canvas);
        if(page==4) drawMonsters(canvas);
        fill(canvas,0xFF173C37); canvas.drawRect(0,465,900,500,p);
        label(canvas,status,450,488,14,0xFFFFFFFF);
        canvas.restore();
    }

    private void drawIsland(Canvas c) {
        label(c,islands[island]+" ISLAND",450,190,24,0xFF173C37);
        fill(c,0xFF8B633F); c.drawOval(new RectF(100,275,800,520),p);
        fill(c,0xFF4D9A55); c.drawOval(new RectF(80,245,820,460),p);
        // Original decorative trees
        for(int i=0;i<5;i++) {
            float x=150+i*150;
            fill(c,0xFF795334); c.drawRect(x-6,250,x+6,310,p);
            fill(c,0xFF32834D); c.drawCircle(x,235,28,p);
        }
        int shown=Math.min(unlocked,4);
        for(int i=0;i<shown;i++) drawMonster(c,250+i*135,310,i);
        button(c,22,405,220,450,"COLLECT COINS",0xFFB77B22);
        button(c,250,405,430,450,"CHANGE ISLAND",0xFF286C88);
        button(c,665,405,878,450,"ISLAND SONG",0xFF674A91);
        label(c,"MONSTERS: "+unlocked+"/120     CASTLE: "+(castleLevel*4)+" BEDS",450,385,16,0xFF173C37);
    }
    private void drawMonster(Canvas c,float x,float y,int id) {
        int col=rarityColor(id);
        fill(c,0xFF2F6742); c.drawOval(new RectF(x-29,y+39,x+29,y+52),p);
        fill(c,col);
        if(id%3==0) c.drawRoundRect(new RectF(x-27,y-38,x+27,y+39),20,20,p);
        else if(id%3==1) c.drawOval(new RectF(x-31,y-35,x+31,y+42),p);
        else { Path q=new Path();q.moveTo(x-30,y+38);q.lineTo(x-20,y-30);q.lineTo(x+8,y-48);q.lineTo(x+30,y+38);q.close();c.drawPath(q,p);}
        fill(c,0xFFFFFFFF); c.drawCircle(x-10,y-3,7,p);c.drawCircle(x+11,y-3,7,p);
        fill(c,0xFF172523);c.drawCircle(x-9,y-2,3,p);c.drawCircle(x+12,y-2,3,p);
        label(c,monsterName(id),x,y+67,11,0xFF173C37);
    }
    private void drawBreed(Canvas c) {
        label(c,"BREEDING STRUCTURE",450,200,24,0xFF173C37);
        label(c,"Combine two monsters to discover a new one.",450,235,16,0xFF173C37);
        label(c,"Unlocked monsters: "+unlocked+" / 120",450,275,19,0xFF173C37);
        long left=Math.max(0,breedFinish-System.currentTimeMillis());
        if(breedFinish>0 && left>0) label(c,"BREEDING: "+(left/1000)+" SECONDS",450,320,22,0xFF8A3F28);
        else if(eggReady || (breedFinish>0 && left==0)) label(c,"NEW EGG READY!",450,320,22,0xFF287D45);
        else label(c,"READY TO BREED",450,320,22,0xFF287D45);
        button(c,280,365,620,425,eggReady||breedFinish>0&&left==0?"HATCH EGG":"START BREEDING",0xFF8B5BA5);
        label(c,"Prototype breeding time: 30 seconds",450,448,13,0xFF173C37);
    }
    private void drawFarm(Canvas c) {
        label(c,"VEGETABLE FARM",450,205,25,0xFF173C37);
        String cropLeft=cropFinish>System.currentTimeMillis()?
            ("GROWING: "+((cropFinish-System.currentTimeMillis())/1000)+" SECONDS"):
            (cropReady?"HARVEST READY!":"PLOT IS EMPTY");
        label(c,cropLeft,450,255,20,0xFF28623A);
        fill(c,0xFF875B35); c.drawRoundRect(new RectF(250,285,650,350),16,16,p);
        for(int i=0;i<5;i++){fill(c,0xFF5BA34C);c.drawCircle(290+i*78,315,17,p);}
        button(c,250,375,445,430,cropReady||cropFinish>0&&cropFinish<=System.currentTimeMillis()?"HARVEST":"PLANT CROPS",0xFF548D3D);
        button(c,465,375,650,430,"FEED MONSTER",0xFFB77B22);
        label(c,"Food grows locally. Feed a monster to level it up.",450,455,13,0xFF173C37);
    }
    private void drawCastle(Canvas c) {
        label(c,"MONSTER CASTLE",450,200,25,0xFF173C37);
        fill(c,0xFF8D8D9B);
        c.drawRect(300,260,600,410,p);
        c.drawRect(270,235,340,410,p); c.drawRect(560,235,630,410,p);
        Path roof=new Path();roof.moveTo(260,260);roof.lineTo(305,190);roof.lineTo(355,260);roof.close();c.drawPath(roof,p);
        roof.reset();roof.moveTo(545,260);roof.lineTo(595,190);roof.lineTo(650,260);roof.close();c.drawPath(roof,p);
        fill(c,0xFF644D75);c.drawRect(410,320,490,410,p);
        label(c,"BEDS: "+(castleLevel*4),450,445,18,0xFF173C37);
        button(c,280,365,620,405,"UPGRADE CASTLE — "+(castleLevel*250)+" COINS",0xFF76528E);
    }
    private void drawMonsters(Canvas c) {
        int start=pageMonsters*12, end=Math.min(120,start+12);
        label(c,"MONSTER BOOK  •  "+(start+1)+"–"+end+" OF 120",450,190,22,0xFF173C37);
        for(int i=start;i<end;i++) {
            int col=i%4,row=(i-start)/4;
            float x=125+col*215,y=245+row*65;
            fill(c,rarityColor(i));c.drawRoundRect(new RectF(x-95,y-24,x+95,y+24),10,10,p);
            String state=i<unlocked?"UNLOCKED":"LOCKED";
            label(c,monsterName(i)+"  •  "+rarity(i)+"  •  "+state,x,y+5,13,0xFF172523);
        }
        button(c,35,420,190,455,"PREVIOUS",0xFF537F71);
        button(c,710,420,865,455,"NEXT",0xFF537F71);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()!=MotionEvent.ACTION_UP)return true;
        float x=e.getX()/sx,y=e.getY()/sy;
        if(y>=112&&y<=151){int t=(int)(x/176);if(t>=0&&t<5){page=t;invalidate();return true;}}
        if(page==0) {
            if(y>400&&x<230){coins+=unlocked*15;status="+"+(unlocked*15)+" COINS COLLECTED!";}
            else if(y>400&&x<450){island=(island+1)%4;status="TRAVELLED TO "+islands[island]+" ISLAND!";}
            else if(y>400&&x>650){playIslandSong();status="ISLAND JAM!";}
        } else if(page==1 && y>355&&y<435) {
            if((eggReady)||(breedFinish>0&&System.currentTimeMillis()>=breedFinish)){
                if(unlocked<120){unlocked++;status="NEW MONSTER DISCOVERED: "+monsterName(unlocked-1)+"!";}
                else status="MONSTER BOOK COMPLETE!";
                eggReady=false;breedFinish=0;
            } else if(breedFinish==0) {
                if(unlocked<2) status="NEED TWO MONSTERS!";
                else {breedFinish=System.currentTimeMillis()+30000;status="BREEDING STARTED!";}
            }
        } else if(page==2) {
            if(y>370&&y<435&&x<450) {
                if(cropReady || cropFinish>0&&System.currentTimeMillis()>=cropFinish){
                    food+=20;cropReady=false;cropFinish=0;status="+20 FOOD HARVESTED!";
                } else if(cropFinish==0){cropFinish=System.currentTimeMillis()+20000;status="VEGETABLES PLANTED!";}
            } else if(y>370&&y<435&&x>450) {
                if(food>=5&&unlocked>0){food-=5;monsterLevel[selectedMonster%unlocked]++;status=monsterName(selectedMonster%unlocked)+" LEVELLED UP!";}
                else status="NEED 5 FOOD!";
            }
        } else if(page==3&&y>350&&y<420) {
            int cost=castleLevel*250;
            if(coins>=cost){coins-=cost;castleLevel++;status="CASTLE UPGRADED! +4 BEDS";}
            else status="NOT ENOUGH COINS!";
        } else if(page==4) {
            if(y>410&&x<220)pageMonsters=Math.max(0,pageMonsters-1);
            if(y>410&&x>680)pageMonsters=Math.min(9,pageMonsters+1);
        }
        save();invalidate();return true;
    }
    private void playIslandSong() {
        if(tone==null)return;
        int[] notes={ToneGenerator.TONE_DTMF_1,ToneGenerator.TONE_DTMF_3,ToneGenerator.TONE_DTMF_5,
            ToneGenerator.TONE_DTMF_3,ToneGenerator.TONE_DTMF_1};
        for(int n:notes) tone.startTone(n,110);
    }
    public void save() {
        try {
            JSONArray levels=new JSONArray();for(int v:monsterLevel)levels.put(v);
            prefs.edit().putInt("coins",coins).putInt("food",food).putInt("castle",castleLevel)
                .putInt("unlocked",unlocked).putInt("island",island).putLong("breed",breedFinish)
                .putLong("crop",cropFinish).putBoolean("egg",eggReady).putBoolean("cropReady",cropReady)
                .putString("levels",levels.toString()).apply();
        } catch(Exception ignored){}
    }
    private void load() {
        coins=prefs.getInt("coins",500);food=prefs.getInt("food",0);
        castleLevel=prefs.getInt("castle",1);unlocked=prefs.getInt("unlocked",3);
        island=prefs.getInt("island",0);breedFinish=prefs.getLong("breed",0);
        cropFinish=prefs.getLong("crop",0);eggReady=prefs.getBoolean("egg",false);
        cropReady=prefs.getBoolean("cropReady",false);
        try {JSONArray a=new JSONArray(prefs.getString("levels","[]"));
            for(int i=0;i<Math.min(a.length(),120);i++)monsterLevel[i]=a.optInt(i,0);
        } catch(Exception ignored){}
    }
    public void refresh() {
        if(breedFinish>0&&System.currentTimeMillis()>=breedFinish)eggReady=true;
        if(cropFinish>0&&System.currentTimeMillis()>=cropFinish)cropReady=true;
        invalidate();
    }
}
