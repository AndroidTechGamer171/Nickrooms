package com.androidtechgamer.oldmsmrevival;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private GameView game;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        game = new GameView(this);
        setContentView(game);
    }
    @Override protected void onPause() {
        if (game != null) game.save();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (game != null) game.refresh();
    }
}
