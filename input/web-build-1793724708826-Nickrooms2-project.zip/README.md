# Nickrooms 2

Separate, harmless Android prank-style app.

- Uses the supplied Nickrooms image as the opening background.
- Shows a fictional “YOU'VE BEEN HACKED BY NICKROOMS... KINDA” message.
- YES dismisses the question and opens the home screen.
- NO plays a fake reboot animation inside the app, then returns to the app.
- No permissions, data collection, wallpaper changes, persistent popups, or real device restart.

Build with Android Gradle Plugin 8.6.1, Kotlin 2.0.20, compile SDK 35. Minimum Android version: 6.0 (API 23).
