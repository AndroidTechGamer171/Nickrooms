package com.androidtechgamer.nickrooms2

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var asked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showIntro()
    }

    private fun showIntro() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.nickrooms_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.82f
        }
        root.addView(logo, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(0x99000000.toInt()) },
            FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 26, 26, 26)
        }
        content.addView(TextView(this).apply {
            text = "YOU'VE BEEN HACKED\\nBY NICKROOMS... KINDA."
            setTextColor(Color.WHITE)
            textSize = 27f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        content.addView(TextView(this).apply {
            text = "\\nRelax. This is a fictional prank screen.\\nNothing on your device has been changed."
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
        })
        content.addView(Button(this).apply {
            text = "CONTINUE"
            setOnClickListener { showQuestion() }
        })
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun showQuestion() {
        if (asked) return
        asked = true
        AlertDialog.Builder(this)
            .setTitle("NICKROOMS 2")
            .setMessage("DID YOU LIKE NICKROOMS?")
            .setCancelable(false)
            .setPositiveButton("YES") { d, _ ->
                d.dismiss()
                Toast.makeText(this, "WELCOME BACK. YOU'RE GOOD TO GO!", Toast.LENGTH_LONG).show()
                showHome()
            }
            .setNegativeButton("NO") { d, _ ->
                d.dismiss()
                fakeReboot()
            }
            .show()
    }

    private fun fakeReboot() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.BLACK)
        }
        val message = TextView(this).apply {
            text = "NICKROOMS SYSTEM RESTART\\n\\n[ SIMULATION ONLY ]\\n\\nRebooting app..."
            setTextColor(0xFFFF8A00.toInt())
            textSize = 22f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
        }
        panel.addView(message)
        setContentView(panel)
        message.startAnimation(AlphaAnimation(0.2f, 1f).apply {
            duration = 600
            repeatCount = 3
            repeatMode = AlphaAnimation.REVERSE
        })
        message.postDelayed({
            message.text = "REBOOT COMPLETE\\n\\nJust kidding. Your phone was not restarted.\\nReturning to Nickrooms 2..."
            message.postDelayed({ showHome() }, 1800)
        }, 2500)
    }

    private fun showHome() {
        val home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.BLACK)
        }
        home.addView(TextView(this).apply {
            text = "NICKROOMS 2"
            setTextColor(0xFFFF8A00.toInt())
            textSize = 32f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        home.addView(TextView(this).apply {
            text = "\\nYOU SURVIVED THE NICKROOMS.\\n\\nNo files accessed. No information collected.\\nNo wallpaper or system settings changed."
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        })
        home.addView(Button(this).apply {
            text = "ASK ME AGAIN"
            setOnClickListener { asked = false; showQuestion() }
        })
        setContentView(home)
    }
}
