package com.androidtechgamer.noedolekcin

import android.app.Activity
import android.app.WallpaperManager
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private var showingLeaderboard = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        applyWallpaper()
        showVideoScreen()
    }

    private fun applyWallpaper() {
        try {
            val bitmap = BitmapFactory.decodeResource(
                resources,
                R.drawable.noedolekcin_wallpaper
            )

            WallpaperManager.getInstance(this).setBitmap(bitmap)
            bitmap.recycle()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showVideoScreen() {
        showingLeaderboard = false

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.rgb(22, 18, 24))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.noedolekcin_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER

            setOnClickListener {
                showLeaderboard()
            }
        }

        layout.addView(
            logo,
            LinearLayout.LayoutParams(-1, 155)
        )

        val title = TextView(this).apply {
            text = "noedolekciN"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }

        layout.addView(title)

        val label = TextView(this).apply {
            text = "VIDEO 1"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 8)
        }

        layout.addView(label)

        val video = VideoView(this)

        layout.addView(
            video,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        setContentView(layout)

        val videoUri = Uri.parse(
            "android.resource://$packageName/${R.raw.video1}"
        )

        video.setVideoURI(videoUri)

        video.setOnPreparedListener { player ->
            player.isLooping = true
            video.start()
        }
    }

    private fun showLeaderboard() {
        showingLeaderboard = true

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(24, 18, 18))
        }

        val title = TextView(this).apply {
            text = "IPAD KID REACTION LEADERBOARD"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(255, 190, 80))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }

        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "FAKE SCORES • JUST FOR FUN"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 18)
        }

        root.addView(subtitle)

        val entries = listOf(
            Triple("SkibidiTablet99", "NO WAY?! 😱", "9850"),
            Triple("iPadBoss_2016", "BRO WHAT?!", "9420"),
            Triple("SnackMode3000", "💀💀💀", "8775"),
            Triple("CartoonFan_X", "I'M TELLING MOM!", "8210"),
            Triple("TinyGamer404", "WHAT IS THIS APP?", "7990"),
            Triple("UltraKidTablet", "THE LOGO MOVED?!", "7450"),
            Triple("RetroSnack.exe", "LOL 😂", "6880"),
            Triple("NoHomeworkPls", "I GOT FOOLED!", "6300")
        )

        val scroll = ScrollView(this)

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        entries.forEachIndexed { index, item ->

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 13, 14, 13)

                setBackgroundColor(
                    if (index % 2 == 0)
                        Color.rgb(55, 35, 35)
                    else
                        Color.rgb(39, 30, 30)
                )
            }

            val username = TextView(this).apply {
                text = "#${index + 1}  ${item.first}   ${item.third} pts"
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }

            val reaction = TextView(this).apply {
                text = "Reaction: ${item.second}"
                textSize = 14f
                setTextColor(Color.rgb(255, 190, 120))
                setPadding(0, 5, 0, 0)
            }

            card.addView(username)
            card.addView(reaction)

            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = 9

            list.addView(card, params)
        }

        scroll.addView(list)

        root.addView(
            scroll,
            LinearLayout.LayoutParams(-1, 0, 1f)
        )

        val back = Button(this).apply {
            text = "BACK TO VIDEO"
            setOnClickListener {
                showVideoScreen()
            }
        }

        root.addView(back)

        setContentView(root)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (showingLeaderboard) {
            showVideoScreen()
        } else {
            super.onBackPressed()
        }
    }
}